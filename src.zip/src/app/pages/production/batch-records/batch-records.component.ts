import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-batch-records',
  templateUrl: './batch-records.component.html',
  styleUrls: ['./batch-records.component.scss']
})
export class BatchRecordsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
