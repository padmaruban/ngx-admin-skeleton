import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchRecordsComponent } from './batch-records.component';

describe('BatchRecordsComponent', () => {
  let component: BatchRecordsComponent;
  let fixture: ComponentFixture<BatchRecordsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchRecordsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
