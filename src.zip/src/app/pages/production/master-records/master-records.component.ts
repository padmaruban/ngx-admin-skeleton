import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-master-records',
  templateUrl: './master-records.component.html',
  styleUrls: ['./master-records.component.scss']
})
export class MasterRecordsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
