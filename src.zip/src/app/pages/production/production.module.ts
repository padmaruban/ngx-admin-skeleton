import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BatchRecordsComponent } from './batch-records/batch-records.component';
import { MasterRecordsComponent } from './master-records/master-records.component';
import { Routes, RouterModule } from '@angular/router';


const routes : Routes = [
  {
    path : 'master-records',
    component : MasterRecordsComponent
  },
  {
    path : 'batch-records',
    component : BatchRecordsComponent
  }  
];



@NgModule({
  declarations: [BatchRecordsComponent, MasterRecordsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class ProductionModule { }
